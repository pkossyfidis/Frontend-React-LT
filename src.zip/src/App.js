import React ,{useState,useEffect} from 'react';
import './App.css';
import InputText from './components/InputText';
import LandingPage from './components/LandingPage';
import Miscard from './components/Miscard';



function App() {
  
  const [mistakes, setMistakes]=useState([]);
  const[input,setInput]=useState("");

  const sumbitText = (e) =>  {
    e.preventDefault();
    fetch('/check/'+ input )
        .then(response => response.json()).then(data => {
        var obj = JSON.parse(JSON.stringify(data));
        setMistakes(obj.matches);
        console.log(obj.matches)
        });
        
    }

  return (
    <div className="App">
      <InputText
        setInput={setInput}
        sumbitText={sumbitText}

      />
      <div className="content-sec">
        {
          mistakes.map(item =>(<Miscard mistakes={item}/>))}
      </div>
    </div>

  );
}

export default App;
