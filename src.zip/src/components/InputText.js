import React from 'react';


function InputText({setInput,sumbitText}){
    const handleSubmit = (event) => {
        setInput(event.target.value);
      };
      return (
        <div className="content">
          <h1>Έλεγχος Κειμένου</h1>
          <div className="text-box-check">
            <form>
              <textarea
                name="text"
                onChange={handleSubmit} 
                placeholder="Γράψε εδώ..."
                id="textarea-box"
              ></textarea>
              <div className="footer">
                <input type="submit" onClick={sumbitText} value="Έλεγχος" id="check-text-btn" />
              </div>
            </form>
          </div>
          <div className="svgbox" styles="overflow: hidden;">
            <div id="top-svg"></div>
          </div>
        </div>
      );
    };
    


export default InputText;