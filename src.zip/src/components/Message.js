//import "react-tippy/dist/tippy.css";
import React, { useState, useEffect, Component } from "react";
import { Button, UncontrolledTooltip, Tooltip } from "reactstrap";

const TooltipItem = ({mistakes})=> {
  //const { item, id } = mistakes;
  const [tooltipOpen, setTooltipOpen] = useState(false);

  const toggle = () => setTooltipOpen(!tooltipOpen);

  return (
    <span>
      <button id="myButton" class="opencard" id={"Tooltip-" + 1}>
        <i class="fas fa-align-justify"></i>
      </button>
      <Tooltip
        className="opencard"
        class="fas fa-align-justify"
        placement="top"//{item.placement}
        isOpen={tooltipOpen}
        target={"Tooltip-" + 1}
        toggle={toggle}
      >
        <div className="tooltipmsg">
          <p>{mistakes}</p>
        </div>
      </Tooltip>
    </span>
  );
};

const TooltipMessage = ({mistakes}) => {
   console.log(mistakes)
  return (
    <>
      {[
        {
          placement: "top",
        },
      ].map(() => {
        return <TooltipItem mistakes={mistakes} />;
      })}
    </>
  );
};

export default TooltipMessage;
