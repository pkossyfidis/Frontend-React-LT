import React, { Component } from "react";
//import "react-tippy/dist/tippy.css";
import Message from "./Message";

function Miscard({mistakes}) {
  return (
    <div  className="mistake-card">
      <div className="icon-wrapper">
        <i className="fas fa-exclmation"></i>
      </div>
      <div className="text-wrapper">
        <h2 id="mistake">{mistakes.shortMessage}</h2>
      </div>
      <Message 
      mistakes={mistakes.message}
      />
    </div>
  );
}

export default Miscard;